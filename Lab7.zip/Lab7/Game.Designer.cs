﻿namespace sdasda
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblTimer = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnIpc = new System.Windows.Forms.Button();
            this.lblHint = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnBtr = new System.Windows.Forms.Button();
            this.btnThmn = new System.Windows.Forms.Button();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblYnlHarf = new System.Windows.Forms.Label();
            this.lblKelNo = new System.Windows.Forms.Label();
            this.lblYanls = new System.Windows.Forms.Label();
            this.lblKelUz = new System.Windows.Forms.Label();
            this.lblWord = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblAyarlar = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(460, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 55);
            this.label1.TabIndex = 15;
            this.label1.Text = "HANGMAN";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.lblTimer);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Location = new System.Drawing.Point(575, 131);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(621, 471);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.BackColor = System.Drawing.Color.IndianRed;
            this.lblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTimer.Location = new System.Drawing.Point(14, 420);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(264, 32);
            this.lblTimer.TabIndex = 12;
            this.lblTimer.Text = "Kalan Süre : 10 sn";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::sdasda.Properties.Resources.man_01;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(114, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(487, 372);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.btnIpc);
            this.groupBox1.Controls.Add(this.lblHint);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.btnBtr);
            this.groupBox1.Controls.Add(this.btnThmn);
            this.groupBox1.Controls.Add(this.lblScore);
            this.groupBox1.Controls.Add(this.lblYnlHarf);
            this.groupBox1.Controls.Add(this.lblKelNo);
            this.groupBox1.Controls.Add(this.lblYanls);
            this.groupBox1.Controls.Add(this.lblKelUz);
            this.groupBox1.Controls.Add(this.lblWord);
            this.groupBox1.Location = new System.Drawing.Point(20, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(543, 472);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // btnIpc
            // 
            this.btnIpc.BackColor = System.Drawing.Color.DarkOrange;
            this.btnIpc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIpc.Location = new System.Drawing.Point(395, 138);
            this.btnIpc.Name = "btnIpc";
            this.btnIpc.Size = new System.Drawing.Size(120, 38);
            this.btnIpc.TabIndex = 8;
            this.btnIpc.Text = "İpucu?";
            this.btnIpc.UseVisualStyleBackColor = false;
            this.btnIpc.Click += new System.EventHandler(this.btnIpc_Click);
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHint.Location = new System.Drawing.Point(25, 143);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(78, 25);
            this.lblHint.TabIndex = 11;
            this.lblHint.Text = "İpucu: ";
            this.lblHint.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox1.Location = new System.Drawing.Point(71, 389);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(58, 45);
            this.textBox1.TabIndex = 9;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // btnBtr
            // 
            this.btnBtr.BackColor = System.Drawing.Color.Gold;
            this.btnBtr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBtr.Location = new System.Drawing.Point(353, 381);
            this.btnBtr.Name = "btnBtr";
            this.btnBtr.Size = new System.Drawing.Size(146, 57);
            this.btnBtr.TabIndex = 7;
            this.btnBtr.Text = "Oyunu Bitir";
            this.btnBtr.UseVisualStyleBackColor = false;
            this.btnBtr.Click += new System.EventHandler(this.btnBtr_Click);
            // 
            // btnThmn
            // 
            this.btnThmn.BackColor = System.Drawing.Color.YellowGreen;
            this.btnThmn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThmn.Location = new System.Drawing.Point(181, 381);
            this.btnThmn.Name = "btnThmn";
            this.btnThmn.Size = new System.Drawing.Size(143, 57);
            this.btnThmn.TabIndex = 6;
            this.btnThmn.Text = "Tahmin Et";
            this.btnThmn.UseVisualStyleBackColor = false;
            this.btnThmn.Click += new System.EventHandler(this.btnThmn_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblScore.Location = new System.Drawing.Point(37, 333);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(164, 32);
            this.lblScore.TabIndex = 5;
            this.lblScore.Text = "PUAN: 100";
            // 
            // lblYnlHarf
            // 
            this.lblYnlHarf.AutoSize = true;
            this.lblYnlHarf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYnlHarf.Location = new System.Drawing.Point(259, 276);
            this.lblYnlHarf.Name = "lblYnlHarf";
            this.lblYnlHarf.Size = new System.Drawing.Size(0, 25);
            this.lblYnlHarf.TabIndex = 4;
            // 
            // lblKelNo
            // 
            this.lblKelNo.AutoSize = true;
            this.lblKelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKelNo.Location = new System.Drawing.Point(259, 235);
            this.lblKelNo.Name = "lblKelNo";
            this.lblKelNo.Size = new System.Drawing.Size(0, 25);
            this.lblKelNo.TabIndex = 3;
            // 
            // lblYanls
            // 
            this.lblYanls.AutoSize = true;
            this.lblYanls.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYanls.Location = new System.Drawing.Point(38, 276);
            this.lblYanls.Name = "lblYanls";
            this.lblYanls.Size = new System.Drawing.Size(186, 25);
            this.lblYanls.TabIndex = 2;
            this.lblYanls.Text = "Yanlış Tahminler: ";
            // 
            // lblKelUz
            // 
            this.lblKelUz.AutoSize = true;
            this.lblKelUz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKelUz.Location = new System.Drawing.Point(38, 235);
            this.lblKelUz.Name = "lblKelUz";
            this.lblKelUz.Size = new System.Drawing.Size(188, 25);
            this.lblKelUz.TabIndex = 1;
            this.lblKelUz.Text = "Kelime Uzunluğu: ";
            // 
            // lblWord
            // 
            this.lblWord.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblWord.Location = new System.Drawing.Point(23, 93);
            this.lblWord.Name = "lblWord";
            this.lblWord.Size = new System.Drawing.Size(492, 38);
            this.lblWord.TabIndex = 0;
            this.lblWord.Text = "label1";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblAyarlar
            // 
            this.lblAyarlar.AutoSize = true;
            this.lblAyarlar.BackColor = System.Drawing.Color.Gainsboro;
            this.lblAyarlar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAyarlar.Location = new System.Drawing.Point(15, 636);
            this.lblAyarlar.Name = "lblAyarlar";
            this.lblAyarlar.Size = new System.Drawing.Size(264, 32);
            this.lblAyarlar.TabIndex = 13;
            this.lblAyarlar.Text = "Kalan Süre : 10 sn";
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1217, 689);
            this.Controls.Add(this.lblAyarlar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Game";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Game_FormClosing);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnIpc;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnBtr;
        private System.Windows.Forms.Button btnThmn;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblYnlHarf;
        private System.Windows.Forms.Label lblKelNo;
        private System.Windows.Forms.Label lblYanls;
        private System.Windows.Forms.Label lblKelUz;
        private System.Windows.Forms.Label lblWord;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Label lblAyarlar;
    }
}