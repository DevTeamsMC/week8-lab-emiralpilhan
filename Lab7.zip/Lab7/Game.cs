﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace sdasda
{
    public partial class Game : Form
    {
        public string selectedCategory;
        public string selectedLevel;
        public int time;
        public string selectedImageSet;
        public bool isValidGame = true;

        private List<WordEntry> allWords = new List<WordEntry>();
        private string wordToGuess;
        private string hint;
        private string worddisplay;
        private int score = 100;
        private int count = 1;
        private List<char> guessedLetters = new List<char>();

        public Game(string ca, string le, int tim, string img)
        {
            InitializeComponent();
            LoadWordsFromCSV();

            selectedCategory = ca;
            selectedLevel = le;
            time = tim;
            selectedImageSet = img;

            lblTimer.Text = $"Süre: 00:{time:00} - Kategori: {selectedCategory} - Seviye: {selectedLevel}";
            lblAyarlar.Text = $"Toplam Süre: 00:{time:00} - Kategori: {selectedCategory} - Seviye: {selectedLevel}";

            var filteredWords = allWords.Where(w =>
                string.Equals(w.Kategori, selectedCategory, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(w.Zorluk, selectedLevel, StringComparison.OrdinalIgnoreCase)).ToList();

            if (filteredWords.Count == 0)
            {
                MessageBox.Show("Seçilen kategori ve zorluk için kelime bulunamadı.");
                isValidGame = false;
                this.Close();
                return;
            }

            Random random = new Random();
            var selected = filteredWords[random.Next(filteredWords.Count)];

            wordToGuess = selected.Kelime.ToLower();
            hint = selected.Ipucu;
            worddisplay = new string('_', wordToGuess.Length);
            lblWord.Text = string.Join(" ", worddisplay.ToCharArray());
            lblHint.Text = "İpucu: " + hint;

            count = 1;
            switch (selectedImageSet)
            {
                case "balon": UpdateBalloonImage(); break;
                case "yumurta": UpdateFlowerImage(); break;
                default: UpdateHangmanImage(); break;
            }

            timer1.Start();
        }

        private void LoadWordsFromCSV()
        {
            string csvPath = "Kelimeler.csv";

            if (!File.Exists(csvPath))
            {
                MessageBox.Show("Kelimeler.csv dosyası bulunamadı.");
                isValidGame = false;
                this.Close();
                return;
            }

            var lines = File.ReadAllLines(csvPath).Skip(1);
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                if (parts.Length >= 4)
                {
                    allWords.Add(new WordEntry
                    {
                        Kelime = parts[1].Trim().ToLower(),
                        Ipucu = parts[2].Trim(),
                        Kategori = parts[0].Trim().ToLower(),
                        Zorluk = parts[3].Trim().ToLower()
                    });

                }
            }
        }

        private void btnThmn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text)) { MessageBox.Show("Lütfen bir harf girin."); return; }

            char guessedLetter = char.ToLower(textBox1.Text[0]);
            if (char.IsLetter(guessedLetter) && !guessedLetters.Contains(guessedLetter))
            {
                if (wordToGuess.Contains(guessedLetter))
                {
                    char[] wordArray = worddisplay.ToCharArray();
                    for (int i = 0; i < wordToGuess.Length; i++)
                    {
                        if (wordToGuess[i] == guessedLetter) wordArray[i] = guessedLetter;
                    }
                    worddisplay = new string(wordArray);
                    lblWord.Text = string.Join(" ", worddisplay.ToCharArray());
                }
                else
                {
                    guessedLetters.Add(guessedLetter);
                    lblYnlHarf.Text = string.Join(", ", guessedLetters);
                    score -= 10;
                    count++;
                    lblScore.Text = "Puan: " + score;

                    switch (selectedImageSet)
                    {
                        case "balon": UpdateBalloonImage(); break;
                        case "yumurta": UpdateFlowerImage(); break;
                        default: UpdateHangmanImage(); break;
                    }

                    if (score == 0)
                    {
                        this.BackColor = Color.Red;
                        MessageBox.Show("Kelimeyi doğru bilemediniz: " + wordToGuess);
                        this.Close();
                        return;
                    }
                }

                if (worddisplay == wordToGuess)
                {
                    this.BackColor = Color.Green;
                    MessageBox.Show("Tebrikler! Kelimeyi doğru bildiniz: " + wordToGuess);
                    this.Close();
                    return;
                }
            }
            textBox1.Clear();
        }

        private void UpdateHangmanImage()
        {
            string path = $"Foto/man-{Math.Min(count, 10):D2}.jpg";
            if (File.Exists(path))
            {
                pictureBox1.Image = Image.FromFile(path);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }


        private void UpdateBalloonImage()
        {
            string path = $"Foto/balon{Math.Min(count, 11)}.png";
            if (File.Exists(path))
            {
                pictureBox1.Image = Image.FromFile(path);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }


        private void UpdateFlowerImage()
        {
            string path = $"Foto/yumurta{Math.Min(count, 11)}.png";
            if (File.Exists(path))
            {
                pictureBox1.Image = Image.FromFile(path);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }


        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) { btnThmn.PerformClick(); e.SuppressKeyPress = true; }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!this.Visible) return;
            time--;
            lblTimer.Text = "Kalan Süre: " + time + " sn";

            if (time < 0)
            {
                timer1.Stop();
                this.BackColor = Color.Red;
                MessageBox.Show("Süre doldu! Kelimeyi doğru bilemediniz: " + wordToGuess);
                this.Close();
            }
        }

        private void Game_FormClosing(object sender, FormClosingEventArgs e) => timer1?.Stop();

        private void btnIpc_Click(object sender, EventArgs e)
        {
            lblHint.Text = "İpucu: " + hint;
            lblHint.Visible = true;
            btnIpc.Visible = false;
        }

        private void btnBtr_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Oyundan çıkmak istediğinize emin misiniz", "Yeni Oyun", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) {
                timer1.Stop();
                this.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 1)
            {
                textBox1.Text = textBox1.Text.Substring(0, 1);
                textBox1.SelectionStart = 1;
            }
        }
    }
}