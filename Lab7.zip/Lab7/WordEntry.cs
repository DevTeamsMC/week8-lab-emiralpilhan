﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sdasda
{
    public class WordEntry
    {
        public string Kelime { get; set; }
        public string Ipucu { get; set; }
        public string Kategori { get; set; }
        public string Zorluk { get; set; }
    }
}
